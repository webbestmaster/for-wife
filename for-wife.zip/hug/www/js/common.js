require('./lib/main-model');
require('pixi.js');
require('gsap');
