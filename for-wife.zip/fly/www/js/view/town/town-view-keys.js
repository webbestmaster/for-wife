/*global define */
define({

	LAYER: {
		TOWN: 'town-view:layer:town',
		HEART: 'town-view:layer:heart',
		FLY: 'town-view:layer:fly'
	}

});
