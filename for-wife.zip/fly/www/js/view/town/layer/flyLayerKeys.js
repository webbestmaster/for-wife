/*global define*/
define({
	FLY_STATE: {
		FLYING: 'fly-view:fly-state:flying',
		NO_ANIMATE: 'fly-view:fly-state:no-animate'
	},
	SHOW: {
		FLY: 'fly-view:show:fly'
	}
});
