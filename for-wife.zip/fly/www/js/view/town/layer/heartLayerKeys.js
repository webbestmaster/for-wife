/*global define*/
define({

	ITEMS_STATE: {
		FALLING: 'heart-view:items-state:falling',
		FLYING: 'heart-view:items-state:flying',
		MOVE_OUT: 'heart-view:items-state:move-out',
		NO_ANIMATE: 'heart-view:items-state:no-animate'
	},
	SHOW: {
		HEART: 'heart-view:show:heart'
	}

});
