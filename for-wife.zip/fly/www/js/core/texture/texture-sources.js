/*global define */
define(function () {

	"use strict";

	return [
		'src/town.json',
		'src/mix.json'
	];

});
