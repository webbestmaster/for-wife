/*global define */
define({
	APPEND: 'renderer:append',
	REMOVE: 'renderer:remove',
	UPDATED: 'renderer:updated'
});
