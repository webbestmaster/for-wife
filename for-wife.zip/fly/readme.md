<h1>Love card for my wife.</h1>

<h2>Abbreviations and acronyms:</h2>
DO - Display Object - main object for UI elements


