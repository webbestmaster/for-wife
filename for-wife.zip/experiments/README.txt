A Pen created at CodePen.io. You can find this one at http://codepen.io/GreenSock/pen/rOjeRq.

 Demo to illustrate how easy it is to use MorphSVGPlugin.