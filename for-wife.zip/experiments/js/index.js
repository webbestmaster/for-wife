/*
Try GreenSock's MorphSVGPlugin for free.
 
 - Press the Fork button
 - add your own SVG, JS and HTML
 - have fun.
 
 Learn more about MorphSVGPlugin here: http://greensock.com/morphSVG
 MorphSVGPlugin is a bonus plugin for Shocking Green and Business Green members: http://www.greensock.com/club

*/


